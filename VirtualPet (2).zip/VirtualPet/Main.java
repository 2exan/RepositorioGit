package Teclat;

public class Main {
    public static void main(String[] args) {
        String gato="";
        String perro="";

        int energiaPerro = 40 + (int) (Math.random() * 21);
        int higienePerro = 40 + (int) (Math.random() * 21);
        int animoPerro = 40 + (int) (Math.random() * 21);
        int pesoPerro = 40 + (int) (Math.random() * 21);

        int energiaGato = 40 + (int) (Math.random() * 21);
        int higieneGato = 40 + (int) (Math.random() * 21);
        int animoGato = 40 + (int) (Math.random() * 21);
        int pesoGato = 40 + (int) (Math.random() * 21);

        int opcion = 0;


        do {
            opcion = OpcionesInicio();

            if (opcion == 1) {
                System.out.print("¿Cómo se llamará tu perro?: ");
                perro = Teclat.llegirString();
                System.out.println("Tu nuevo perro se llama " + perro + ".");

                do {
                    opcion = OpcionesPerro();

                    if (opcion == 1) {
                        energiaPerro = Math.min(energiaPerro + 25, 100);
                        animoPerro = Math.min(animoPerro + 10, 100);
                        System.out.println("¡Shhhhh! " + perro + " está durmiendo.");
                        EstadoPerro(energiaPerro, higienePerro, animoPerro, pesoPerro);

                        if (!VidaPerro(perro, energiaPerro, higienePerro, animoPerro, pesoPerro)) {
                            return;
                        }
                    } else if (opcion == 2) {
                        energiaPerro = Math.max(energiaPerro - 20, 0);
                        animoPerro = Math.min(animoPerro + 20, 100);
                        System.out.println(perro + " está jugando alegremente! ^_^");
                        EstadoPerro(energiaPerro, higienePerro, animoPerro, pesoPerro);

                        if (!VidaPerro(perro, energiaPerro, higienePerro, animoPerro, pesoPerro)) {
                            return;
                        }
                    } else if (opcion == 3) {
                        energiaPerro = Math.min(energiaPerro + 10, 100);
                        higienePerro = Math.max(higienePerro - 15, 0);
                        pesoPerro = Math.min(pesoPerro + 10, 100);
                        System.out.println("Qué rico!");
                        EstadoPerro(energiaPerro, higienePerro, animoPerro, pesoPerro);

                        if (!VidaPerro(perro, energiaPerro, higienePerro, animoPerro, pesoPerro)) {
                            return;
                        }
                    } else if (opcion == 4) {
                        energiaPerro = Math.max(energiaPerro - 10, 0);
                        higienePerro = Math.min(higienePerro + 25, 100);
                        animoPerro = Math.max(animoPerro - 15, 0);
                        System.out.println("¡Splash! " + perro + " se está bañando!");
                        EstadoPerro(energiaPerro, higienePerro, animoPerro, pesoPerro);

                        if (!VidaPerro(perro, energiaPerro, higienePerro, animoPerro, pesoPerro)) {
                            return;
                        }
                    }




                } while (opcion != 0);

            } else if (opcion == 2) {
                System.out.print("¿Cómo se llamará tu gato?: ");
                gato = Teclat.llegirString();
                System.out.println("Tu nueva gato se llama " + gato + ".");

                do {
                    opcion = OpcionesGato();

                    if (opcion == 1) {
                        energiaGato = Math.min(energiaGato + 20, 100);
                        animoGato = Math.min(animoGato + 10, 100);
                        System.out.println("Shhhhh! " + gato + " está durmiendo.");
                        EstadoGato(energiaGato, higieneGato, animoGato, pesoGato);

                        if(!VidaGato(gato, energiaGato, higieneGato, animoGato, pesoGato)) {
                            return;
                        }
                    } else if (opcion == 2) {
                        energiaGato = Math.max(energiaGato - 20, 0);
                        animoGato = Math.min(animoGato + 20, 100);
                        System.out.println(gato + " está jugando alegremente! ^_^");
                        EstadoGato(energiaGato, higieneGato, animoGato, pesoGato);
                        if(!VidaGato(gato, energiaGato, higieneGato, animoGato, pesoGato)) {
                            return;
                        }
                    } else if (opcion == 3) {
                        energiaGato = Math.max(energiaGato - 10, 0);
                        higieneGato = Math.max(higieneGato - 15, 0);
                        pesoGato = Math.min(pesoGato + 10, 100);
                        System.out.println("Qué rico!^.^");

                        if(!VidaGato(gato, energiaGato, higieneGato, animoGato, pesoGato)) {
                            return;
                        }
                        EstadoGato(energiaGato, higieneGato, animoGato, pesoGato);
                    } else if (opcion == 4) {
                        energiaGato = Math.max(energiaGato - 5, 0);
                        higieneGato = Math.min(higieneGato + 25, 100);
                        animoGato = Math.min(animoGato + 10, 100);
                        System.out.println("Autolimpieza en progreso, " + gato + " mueve la cola mientras se acicala.");
                        EstadoGato(energiaGato, higieneGato, animoGato, pesoGato);

                        if(!VidaGato(gato, energiaGato, higieneGato, animoGato, pesoGato)) {
                            return;
                        }
                    }


                } while (opcion != 0);

            }

        } while (opcion != 0);

    }

    public static void EstadoPerro(int energia, int higiene, int animo, int peso) {
        System.out.println("Estado:");
        System.out.println("Energia: " + energia + "/100");
        System.out.println("Higiene: " + higiene + "/100");
        System.out.println("Animo: " + animo + "/100");
        System.out.println("Peso: " + peso + "/100");
    }

    public static void EstadoGato(int energia, int higiene, int animo, int peso) {
        System.out.println("Estado:");
        System.out.println("Energia: " + energia + "/100");
        System.out.println("Higiene: " + higiene + "/100");
        System.out.println("Animo: " + animo + "/100");
        System.out.println("Peso: " + peso + "/100");
    }

    public static boolean VidaPerro(String perro, int energia, int higiene, int animo, int peso) {
        if (energia <= 0 || higiene <= 0 || animo <= 0 || peso <= 0) {
            System.out.println("Oh no! " + perro + " ha muerto...");
            return false;
        }
        return true;
    }

    public static boolean VidaGato(String gato, int energia, int higiene, int animo, int peso) {
        if (energia <= 0 || higiene <= 0 || animo <= 0 || peso <= 0) {
            System.out.println("Oh no! " + gato + " ha muerto...");
            return false;
        }
        return true;
    }

    public static int OpcionesInicio() {
        System.out.println("¿Qué mascota quieres?:");
        System.out.println("[1] Perro");
        System.out.println("[2] Gato");
        System.out.println("[0] Salir");
        System.out.print("Ingrese su opción: ");
        int opcion = Teclat.llegirInt();
        return opcion;
    }

    public static int OpcionesPerro() {
        System.out.println("Qué quieres hacer?:");
        System.out.println("[1] Dormir");
        System.out.println("[2] Jugar");
        System.out.println("[3] Comer");
        System.out.println("[4] Bañarse");
        System.out.println("[0] Salir de la App");
        System.out.print("Ingrese su opcion: ");
        int opcion = Teclat.llegirInt();
        return opcion;
    }

    public static int OpcionesGato() {
        System.out.println("Qué quieres hacer?:");
        System.out.println("[1] Dormir");
        System.out.println("[2] Jugar");
        System.out.println("[3] Comer");
        System.out.println("[4] Autolamerse");
        System.out.println("[0] Salir de la App");
        System.out.print("Ingrese su opcion: ");
        int opcion = Teclat.llegirInt();
        return opcion;
    }
}

